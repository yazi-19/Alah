<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <title>Tambah|Penjualan</title>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-success">
        <div class="container-fluid">
            <a class="navbar-brand text-black" href="#">App Kasir</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active text-black" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-black" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Penjualan
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="tambah-penjualan.php">Tambah Penjualan</a></li>
                            <li><a class="dropdown-item" href="tampil-penjualan1.php">Tampil Penjualan</a></li>
                            <li><a class="dropdown-item" href="cetak-penjualan.php">Cetak Penjualan</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active text-black" aria-current="page" href="../config/logout.php" onclick="return confirm('Apakah Anda Yakin Ingin Logout ???')">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <h3>Tambah Penjualan</h3>
        <div class="row">
            <input type="text" id="searchBox" class="form-control mb-3" placeholder="Cari Barang...">
            <form class="row g-3" action="simpan-penjualan1.php" method="post">
                <div class="col-12">
                    <label for="id_pelanggan" class="form-label">ID Pelanggan</label>
                    <select id="id_pelanggan" name="id_pelanggan" class="form-control">
                        <option value="-">- Pilih Pelanggan -</option>
                        <?php
                        include "../config/koneksi.php";
                        $sql = mysqli_query($config, "SELECT * FROM pelanggan");
                        while ($data1 = mysqli_fetch_array($sql)) {
                            echo "<option value='$data1[id_pelanggan]'>$data1[id_pelanggan] - $data1[nama_pelanggan]</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-12">
                    <label for="tgl_penjualan" class="form-label">Tanggal Penjualan</label>
                    <input type="date" class="form-control" id="tgl_penjualan" name="tgl_penjualan" value="<?php echo date('Y-m-d'); ?>" readonly>
                </div>
                <div id="product-container"></div>
                <div class="col-12 mt-2">
                    <button type="button" class="btn btn-success" onclick="addRow()">Tambah Barang</button>
                </div>
                <div class="col-12">
                    <label for="total" class="form-label">Total Harga</label>
                    <input type="number" class="form-control" id="total" name="total" placeholder="Total Harga" readonly>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-success">Simpan</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function addRow() {
            const container = document.getElementById('product-container');
            const newRow = document.createElement('div');
            newRow.classList.add('row', 'g-3', 'mt-2');
            newRow.innerHTML = `
                <div class="col-4">
                    <label for="id_barang" class="form-label">Barang</label>
                    <select name="id_barang[]" class="form-control" oninput="updateSubtotal(this)">
                        <option value="-">- Pilih Barang -</option>
                        <?php
                        $sql = mysqli_query($config, "SELECT * FROM barang");
                        while ($data1 = mysqli_fetch_array($sql)) {
                            echo "<option value='$data1[id_barang]' data-harga='$data1[harga]'>$data1[id_barang] - $data1[nama_barang]</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-3">
                    <label for="jumlah" class="form-label">Jumlah Barang</label>
                    <input type="number" class="form-control" name="jumlah[]" value="1" oninput="updateSubtotal(this)">
                </div>
                <div class="col-3">
                    <label for="subtotal" class="form-label">Sub Total</label>
                    <input type="number" class="form-control" name="subtotal[]" readonly>
                </div>
                <div class="col-2 d-flex align-items-end">
                    <button type="button" class="btn btn-danger" onclick="this.parentElement.parentElement.remove(); updateTotal()">Hapus</button>
                </div>
            `;
            container.appendChild(newRow);
        }
        
        function updateSubtotal(element) {
            const row = element.closest('.row');
            const barang = row.querySelector('select[name="id_barang[]"]');
            const harga = barang.options[barang.selectedIndex].dataset.harga || 0;
            const jumlah = row.querySelector('input[name="jumlah[]"]').value || 1;
            row.querySelector('input[name="subtotal[]"]').value = harga * jumlah;
            updateTotal();
        }
        
        function updateTotal() {
            let total = 0;
            document.querySelectorAll('input[name="subtotal[]"]').forEach(input => {
                total += parseFloat(input.value) || 0;
            });
            document.getElementById('total').value = total;
        }

        document.getElementById("searchBox").addEventListener("input", function() {
            let filter = this.value.toLowerCase();
            document.querySelectorAll("#product-container select[name='id_barang[]'] option").forEach(option => {
                let text = option.textContent.toLowerCase();
                option.style.display = text.includes(filter) ? "block" : "none";
            });
        });
    </script>
</body>
</html>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <title>Tambah|Penjualan</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-success">
        <div class="container-fluid">
            <a class="navbar-brand text-black" href="#">App Kasir</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active text-black" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-black" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Penjualan
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="tambah-penjualan.php">Tambah Penjualan</a></li>
                            <li><a class="dropdown-item" href="tampil-penjualan1.php">Tampil Penjualan</a></li>
                            <li><a class="dropdown-item" href="cetak-penjualan.php">Cetak Penjualan</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <h3>Tambah Penjualan</h3>
        <div class="row">
            <form class="row g-3" action="simpan-penjualan1.php" method="post">
                <div class="col-12">
                    <label for="id_pelanggan" class="form-label">ID Pelanggan</label>
                    <select id="id_pelanggan" name="id_pelanggan" class="form-control">
                        <option value="-">- Pilih Pelanggan -</option>
                        <?php
                        include "../config/koneksi.php";
                        $sql = mysqli_query($config, "SELECT * FROM pelanggan");
                        while ($data1 = mysqli_fetch_array($sql)) {
                            echo "<option value='$data1[id_pelanggan]'>$data1[id_pelanggan] - $data1[nama_pelanggan]</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="col-12">
                    <label for="search-barang" class="form-label">Cari Barang</label>
                    <inpt type="text" id="search-barang" class="form-control" placeholder="Ketik nama barang...">
                </div>

                <div id="product-container">
                    <div class="product-row row g-3">
                        <div class="col-4">
                            <label for="id_barang" class="form-label">Barang</label>
                            <select id="id_barang" name="id_barang[]" class="form-control">
                                <option value="-">- Pilih Barang -</option>
                                <?php
                                $sql = mysqli_query($config, "SELECT * FROM barang");
                                $arrayjs = "var varbarang = new Array();\n";
                                while ($data1 = mysqli_fetch_array($sql)) {
                                    echo "<option value='$data1[id_barang]'>$data1[id_barang] - $data1[nama_barang]</option>";
                                    $arrayjs .= "varbarang['" . $data1['id_barang'] . "'] = {vharga:'" . addslashes($data1['harga']) . "'};\n";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="col-3">
                            <label for="jumlah" class="form-label">Jumlah Barang</label>
                            <input type="number" class="form-control" name="jumlah[]" value="1" readonly>
                        </div>

                        <div class="col-3">
                            <label for="subtotal" class="form-label">Sub Total</label>
                            <input type="number" class="form-control" name="subtotal[]" placeholder="Sub Total" readonly>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script>
        <?php echo $arrayjs; ?>
        document.getElementById("search-barang").addEventListener("input", function () {
            let searchQuery = this.value.toLowerCase();
            let options = document.querySelectorAll("#id_barang option");
            options.forEach(option => {
                if (option.text.toLowerCase().includes(searchQuery)) {
                    option.style.display = "block";
                } else {
                    option.style.display = "none";
                }
            });
        });
    </script>
</body>
</html>
