<?php
include "../config/koneksi.php"; // Koneksi ke database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $id_pelanggan = $_POST['id_pelanggan'];
    $tgl_penjualan = $_POST['tgl_penjualan'];
    $total_harga = $_POST['total'];
    $id_barang_array = $_POST['id_barang']; // Array ID barang
    $jumlah_array = $_POST['jumlah']; // Array jumlah barang
    $subtotal_array = $_POST['subtotal']; // Array subtotal

    // Validasi data
    if ($id_pelanggan == '-' || empty($id_barang_array)) {
        echo "<script>alert('Pelanggan atau barang belum dipilih!');</script>";
        exit;
    }

    // Mulai transaksi
    mysqli_begin_transaction($config);

    try {
        // Simpan data ke tabel `penjualan`
        $query_penjualan = "INSERT INTO penjualan (id_pelanggan, tgl_penjualan, total) VALUES ('$id_pelanggan', '$tgl_penjualan', '$total_harga')";
        mysqli_query($config, $query_penjualan);

        // Ambil ID penjualan yang baru saja dimasukkan
        $id_penjualan = mysqli_insert_id($config);

        // Simpan detail penjualan
        foreach ($id_barang_array as $index => $id_barang) {
            $jumlah = $jumlah_array[$index];
            $subtotal = $subtotal_array[$index];


}
// Ambil harga satuan barang
$result_barang = mysqli_query($config, "SELECT harga, stok FROM barang WHERE id_barang = $id_barang");
$barang = mysqli_fetch_assoc($result_barang);

if ($barang['stok'] < $jumlah) {

throw new Exception("Stok barang tidak mencukupi untuk barang ID: $id_barang");
}
$harga_satuan = $barang['harga'];

// Masukkan ke tabel `detail_penjualan`
$query_detail = "INSERT INTO detail_penjualan (id_penjualan, id_barang, jumlah, harga, subtotal) VALUES ('$id_penjualan', '$id_barang', '$jumlah', '$harga_satuan','$subtotal')"; 
mysqli_query($config, $query_detail);
// Kurangi stok barang
$stok_baru = $barang['stok'] - $jumlah;
$query_update_stok = "UPDATE barang SET stok = '$stok_baru' WHERE id_barang = '$id_barang'"; 
mysqli_query($config, $query_update_stok);
// Commit transaksi
mysqli_commit($config);
echo "<script> alert('Data Penjualan Tersimpan !!!'); location.href=('tampil-penjualan1.php'); </script>"; 
} catch (Exception $e) {
}
// Rollback jika terjadi kesalahan
mysqli_rollback($config);
echo "Terjadi kesalahan: ". $e->getMessage();
}
?>
