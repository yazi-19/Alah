<?php
include("../config/koneksi.php");
$id_barang = $_POST['id_barang'];
$nama_barang = $_POST['nama_barang'];
$harga = $_POST['harga'];
$stok = $_POST['stok'];

$query = mysqli_query($config, "update barang set id_barang='$id_barang', nama_barang='$nama_barang', harga='$harga', stok='$stok'
	where id_barang='$id_barang'");

	if ($query) {
		echo "<script>alert('Data Barang Di Update !!!');location.href=('tampil-barang.php');</script>";
	} else {

	     
		echo "<script type='text/javascript'>alert('Data Produk Gagal Di Update !!!'); history.back(self);</script>";
	}
?>