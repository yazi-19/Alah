
<?php
    date_default_timezone_set("Asia/Jakarta");
    $tanggal = date("d-m-Y H:i:s");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Struk</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        .struk {
            width: 300px;
            border: 1px solid #000;
            padding: 10px;
        }
        .btn {
            margin-top: 10px;
            padding: 5px 10px;
            cursor: pointer;
        }
        @media print {
            .btn { display: none; }
        }
    </style>
</head>
<body>
    <div class="struk" id="struk">
        <h3>Toko ABC</h3>
        <p>Tanggal: <?php echo $tanggal; ?></p>
        <p>Barang: Kopi</p>
        <p>Harga: Rp 10.000</p>
        <p>Total: Rp 10.000</p>
        <hr>
        <p>Terima Kasih!</p>
    </div>
    <button class="btn" onclick="cetakStruk()">Cetak Struk</button>
    
    <script>
        function cetakStruk() {
            window.print();
        }
    </script>
</body>
</html>
