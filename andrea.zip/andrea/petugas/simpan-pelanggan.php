
<?php
include("../config/koneksi.php");
$id_pelanggan = $_POST['id_pelanggan'];
$nama_pelanggan = $_POST['nama_pelanggan'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['no_hp'];


$cek = mysqli_query($config, "SELECT * FROM pelanggan WHERE id_pelanggan='$id_pelanggan'"); // Menggunakan $id_barang, bukan $id
if (mysqli_num_rows($cek) > 0) {
    echo "<script>alert('ID sudah ada, silahkan gunakan ID lain');window.location.href = 'tambah-pelanggan.php';</script>";
} else {
	$query = mysqli_query($config, "insert into pelanggan (id_pelanggan, nama_pelanggan, alamat, no_hp)
	values ('$id_pelanggan','$nama_pelanggan','$alamat','$no_hp')");

    if ($query) {
        echo "<script>alert('Data Barang Tersimpan !!!');location.href='tampil-pelanggan.php';</script>";
    } else {
        echo "<script type='text/javascript'>alert('Data Produk Gagal Tersimpan !!!'); history.back(self);</script>";
    }
}
?>
