<?php
// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "appkasir_yazid");

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari form (pastikan method POST)
$username = $_POST['username'];
$password = $_POST['password'];

// Hash password dengan bcrypt
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Simpan ke database
$sql = "INSERT INTO users (username, password_hash) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $username, $hashed_password);

if ($stmt->execute()) {
    echo "Registrasi berhasil!";
} else {
    echo "Error: " . $stmt->error;
}

// Tutup koneksi
$stmt->close();
$conn->close();
?>
