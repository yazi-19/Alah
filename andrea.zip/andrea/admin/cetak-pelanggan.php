<!doctype html>
<html lang="en">
  <head>
    <title>Aplikasi Kasir</title>
    <script language="javascript1.2">
      function printpage(){
        window.print();
      }
      </script>
  </head>
  <body onload="printpage()">
    <h2>
      <center>Data Pelanggan</center>
    </h2>
    <table border="1" align="center">
      <tr>
        <th>NO</th>
        <th>ID Pelanggan</th>
        <th>Nama Pelanggan</th>
        <th>Alamat</th>
        <th>Nomer Telepon</th>
      </tr>
      <?php
      include("../config/koneksi.php");
      $i = 1;
      $query = mysqli_query($config, "select * from pelanggan");
      while ($data = mysqli_fetch_array($query)){
        echo "<tr>
        <td>$1</td>
        <td>$data[id_pelanggan]</td>
        <td>$data[nama_pelanggan]</td>
        <td>$data[alamat]</td>
        <td>$data[no_hp]</td>
        </tr>";
        $i = $i + 1;
      }
      ?>

    </table>
    </body>
