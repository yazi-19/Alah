<!doctype html>
<html lang="en">
  <head>
    <title>Cetak Barang</title>
    <script language="javascript1.2">
      function printpage(){
        window.print();
      }
      </script>
  </head>
  <body onload="printpage()">
    <h2>
      <center>Data Barang</center>
    </h2>
    <table border="1" align="center">
      <tr>
        <th>NO</th>
        <th>ID Barang</th>
        <th>Nama Barang</th>
        <th>harga</th>
        <th>stok</th>
      </tr>
      <?php
      include("../config/koneksi.php");
      $i = 1;
      $query = mysqli_query($config, "select * from barang");
      while ($data = mysqli_fetch_array($query)){
        echo "<tr>
        <td>$1</td>
        <td>$data[id_barang]</td>
        <td>$data[nama_barang]</td>
        <td>Rp. $data[harga]</td>
        <td>$data[stok]</td>
        </tr>";
        $i = $i + 1;
      }
      ?>

    </table>
    </body>
