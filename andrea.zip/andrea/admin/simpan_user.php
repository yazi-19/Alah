
 <?php
include("../config/koneksi.php");
$id_user = $_POST['id_user'];
$nama_user = $_POST['nama_user'];
$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];


$cek = mysqli_query($config, "SELECT * FROM user WHERE id_user='$id_user'"); // Menggunakan $id_barang, bukan $id
if (mysqli_num_rows($cek) > 0) {
    echo "<script>alert('ID sudah ada, silahkan gunakan ID lain');window.location.href = 'tambah-user.php';</script>";
} else {
	$query = mysqli_query($config, "insert into user (id_user, nama_user, username, password, role)
	values ('$id_user','$nama_user','$username','$password','$role')");

    if ($query) {
        echo "<script>alert('Data Barang Tersimpan !!!');location.href='tampil-user.php';</script>";
    } else {
        echo "<script type='text/javascript'>alert('Data Produk Gagal Tersimpan !!!'); history.back(self);</script>";
    }
}
?>
