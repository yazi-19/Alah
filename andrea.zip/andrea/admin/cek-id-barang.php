<?php
include "../config/koneksi.php"; // Pastikan koneksi ke database sudah benar

if (isset($_GET['id_barang'])) {
    $id_barang = $_GET['id_barang'];

    // Query untuk memeriksa apakah ID sudah ada di database
    $query = $conn->prepare("SELECT COUNT(*) FROM barang WHERE id_barang = ?");
    $query->bind_param("s", $id_barang);
    $query->execute();
    $query->bind_result($count);
    $query->fetch();
    $query->close();

    echo json_encode(["exists" => $count > 0]); // Kirim hasil dalam format JSON
}
?>
