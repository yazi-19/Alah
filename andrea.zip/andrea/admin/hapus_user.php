<?php 
include("../config/koneksi.php");
$hasil = $_REQUEST['id_user'];
$perintah = mysqli_query($config, "delete from user where id_user='$hasil'");
if ($perintah) {
	echo "<script>alert('Data User Berhasil Di Hapus!');
	location.href=('tampil-user.php');
	</script>;
	";
} else {
	echo "<script>alert('Data User Gagal Di Hapus!');
	history.back(self)</script>;";
}
?>