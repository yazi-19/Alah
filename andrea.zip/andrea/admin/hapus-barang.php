<?php 
include("../config/koneksi.php");
$hasil = $_REQUEST['id_barang'];
$perintah = mysqli_query($config, "delete from barang where id_barang='$hasil'");
if ($perintah) {
	echo "<script>alert('Data Barang Berhasil Di Hapus!');
	location.href=('tampil-barang.php');
	</script>;
	";
} else {
	echo "<script>alert('Data Barang Gagal Di Hapus!');
	history.back(self)</script>;";
}
?>