<?php
// Koneksi ke database
include '../config/koneksi.php';

$duplicate_id = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_barang = $_POST['id_barang'];
    $nama_barang = $_POST['nama_barang'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    // Cek apakah ID sudah ada di database
    $query = "SELECT id_barang FROM barang WHERE id_barang = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $id_barang);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $duplicate_id = true; // Tandai bahwa ID sudah ada
    } else {
        // Simpan data ke database jika ID belum ada
        $query = "INSERT INTO barang (id_barang, nama_barang, harga, stok) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssii", $id_barang, $nama_barang, $harga, $stok);
        if ($stmt->execute()) {
            echo "<script>alert('Barang berhasil ditambahkan!'); window.location='tampil-barang.php';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan barang!');</script>";
        }
    }

    $stmt->close();
    $conn->close();
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <title>Tambah Barang</title>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-info">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">App Kasir</a>
    </div>
</nav>

<div class="container mt-4">
    <h3>Tambah Barang</h3>
    <?php if ($duplicate_id): ?>
        <div class="alert alert-danger">ID Barang sudah ada! Gunakan ID lain.</div>
    <?php endif; ?>
    
    <form class="row g-3" action="" method="post">
        <div class="col-12">
            <label for="inputIDBarang" class="form-label">ID Barang</label>
            <input type="text" class="form-control" name="id_barang" id="inputIDBarang" placeholder="ID Barang" required>
        </div>
        <div class="col-12">
            <label for="inputNamaBarang" class="form-label">Nama Barang</label>
            <input type="text" class="form-control" name="nama_barang" id="inputNamaBarang" placeholder="Nama Barang" required>
        </div>
        <div class="col-12">
            <label for="inputHarga" class="form-label">Harga</label>
            <input type="text" class="form-control" name="harga" id="inputHarga" placeholder="Harga" required>
        </div>
        <div class="col-12">
            <label for="inputStok" class="form-label">Stok Barang</label>
            <input type="number" class="form-control" name="stok" id="inputStok" placeholder="Stok Barang" required>
        </div>
        <div class="col-12">
            <button type="submit" id="btnSimpan" class="btn btn-primary" <?php if ($duplicate_id) echo 'disabled'; ?>>Simpan</button>
        </div>
    </form>
</div>

<script>
    // Jika ID barang sudah ada, tampilkan alert dan nonaktifkan tombol simpan
    let duplicate = <?php echo json_encode($duplicate_id); ?>;
    if (duplicate) {
        alert('ID Barang sudah ada! Gunakan ID lain.');
        document.getElementById('btnSimpan').disabled = true;
    }
</script>

<script src="../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
