<?php 
include("../config/koneksi.php");
$hasil = $_REQUEST['id_pelanggan'];
$perintah = mysqli_query($config, "delete from pelanggan where id_pelanggan='$hasil'");
if ($perintah) {
	echo "<script>alert('Data Pelanggan Berhasil Di Hapus!');
	location.href=('tampil-pelanggan.php');
	</script>;
	";
} else {
	echo "<script>alert('Data Pelanggan Gagal Di Hapus!');
	history.back(self)</script>;";
}
?>