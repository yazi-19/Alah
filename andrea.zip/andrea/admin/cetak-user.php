<!doctype html>
<html lang="en">
  <head>
    <title>Aplikasi Kasir</title>
    <script language="javascript1.2">
      function printpage(){
        window.print();
      }
      </script>
  </head>
  <body onload="printpage()">
    <h2>
      <center>Data Pelanggan</center>
    </h2>
    <table border="1" align="center">
      <tr>
        <th>NO</th>
        <th>ID User</th>
        <th>Nama User</th>
        <th>Username</th>
        <th>Password</th>
        <th>Role</th>
      </tr>
      <?php
      include("../config/koneksi.php");
      $i = 1;
      $query = mysqli_query($config, "select * from user");
      while ($data = mysqli_fetch_array($query)){
        echo "<tr>
        <td>$1</td>
        <td>$data[id_user]</td>
        <td>$data[nama_user]</td>
        <td>$data[username]</td>
        <td>$data[password]</td>
        <td>$data[role]</td>
        </tr>";
        $i = $i + 1;
      }
      ?>

    </table>
    </body>
